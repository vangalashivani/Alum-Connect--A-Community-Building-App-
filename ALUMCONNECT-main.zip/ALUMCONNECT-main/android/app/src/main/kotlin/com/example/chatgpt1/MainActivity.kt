package com.example.chatgpt1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
